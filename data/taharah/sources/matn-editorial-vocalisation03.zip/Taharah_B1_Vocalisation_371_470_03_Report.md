# Tahārah B1 matn vocalisation, H371–470: pass 03

This is an **editorial vowel draft** on the immutable Mirqāt lexical text. Bushrā and Sunnah.com Arabic supply vowel witnesses; neither controls Mirqāt wording. The file is not a diplomatic copy of Mirqāt's printed vowels and is not final scholarly proof.

## Coverage and validation

- 100 numbered entries (H371–470), 3,167 Arabic word tokens; all have at least one vowel mark. The conservative bare-consonant detector now flags 0 words. This detector is not proof of complete or correct vocalisation.
- Base letters and punctuation follow the B1 lexical text in `Mirqat_Kitab_al_Taharah_B1_B2_Consolidated_Review_04.json` exactly; 0 impossible mark clusters in the configured QA.
- 15 entries (H378, H381, H382, H387, H396, H399, H403, H404, H409, H420, H432, H439, H455, H458, H470) have complete editorial scan passes; 85 remain `partial_editorial_vocalisation_unproofed`. There are 0 machine-flagged unresolved words, but these partial entries still need full vowel review.
- 2,997 exact-base Sunnah alignments; 27 normalized-only and 143 no-alignment tokens received no Sunnah vowel transfer. 448 exact-base tokens received 1161 Sunnah marks.
- 1,975 fully marked exact-base Bushrā/Sunnah agreements were audited across all entries. The builder made 13 corrections and confirmed 1941 unchanged draft readings; 20 additional manually reviewed readings agree; H428 is the only retained difference. Note that a later manual H451 correction also follows the agreed witnesses.
- 159 recorded vowel variant words. The focused queue has 327 unique word positions with a variant or non-exact Sunnah alignment. Of these, 20 belong to fully reviewed entries, 47 have a new scan checked editorial reading, 0 have inherited manual review, 21 are grammar or name based editorial readings, and 239 still lack token level scan review. It is a review priority list, not the entire final proof workload.

## Significant decisions

- H418 `قَوْمٌ` removes a spurious shadda. H440 `كُنْتُ`, `وَبَيْنَهُ`, `مُعَاذَةَ`, `عَائِشَةُ` were corrected against Mirqāt p132 and Bushrā p93. H394 `بِإِنَاءٍ` removes a false shadda; H407 `أَصَابِعَ` and H457 `إِنِّي` correct inherited vowel errors. H451 `يَنْجَسُ` follows Mirqāt commentary p141, which explicitly says **بفتح الجيم**. H433 `غُسْلٌ` follows Mirqāt's matn without `مِنْ`; its commentary p126 explicitly distinguishes the `مِنْ غُسْلٍ` variant.
- H428 retains `كُلُّهُ` although Bushrā and Sunnah.com read `كُلَّهُ`; Mirqāt commentary p123 calls it an emphasis of subject `جَسَدُهُ`, supporting nominative. This is the one retained exception among the 1,975 fully marked witness agreements.
- Mirqāt's `ماجة` spelling remains unchanged. `مَاجَةَ` is an editorial case reading in the Ibn Mājah citation; the external witness uses final `ه`, so its marks were never transferred across the differing base letters.
- The repeated independent citation `مُتَّفَقٌ عَلَيْهِ` was checked against Bushrā scans. `فِي الْمُتَّفَقِ عَلَيْهِ` at H394 is a different grammatical context.

## Outstanding work

Full independent word-by-word vowel proof remains for the 85 partial entries, including the 327 focused witness questions in `Taharah_B1_Vocalisation_371_470_03_Review_Queue.json`. The current zero-gap heuristic must not be interpreted as completed B1 scholarly verification or Stage E.
