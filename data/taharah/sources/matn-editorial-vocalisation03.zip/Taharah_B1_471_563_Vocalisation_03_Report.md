# Kitāb al-Ṭahārah B1 editorial vocalisation: H471–563

The range contains 93 hadith records and 3,275 Arabic word tokens. Every record preserves the Mirqāt consonantal wording from Consolidated Review 04, except the two explicit H518/H528 lexical corrections in `Taharah_B1_04_to_05_Errata.json`. The source 04 file was not changed. Bushrā and Sunnah.com supply comparison vowels only; H527 uses Bushrā p103 because the Sunnah Arabic row is a different narration.

## This pass

- Resolved and recorded inherited witness conflicts per word. All 24 final differences against exact-base Sunnah Arabic have a visual Mirqāt or Bushrā page decision in `word_review`. Examples: H492 `تُزْرِمُوهُ` follows the explicit Mirqāt p181 commentary; H541 `مَيْتًا` follows Mirqāt p222, which says the word may be read lightly or with gemination.
- Corrected scan-supported case endings and forms, including H471 `بِفَضْلِ`, H480 `طَيِّبَةٌ`, H520 `وَنَوْمٍ`, H544 `عَبَّاسٍ` and `بِوَاجِبٍ`, H545 `لَبَنٍ`, H550 `مِرْطٍ`, H558 `دَمٌ`, and H500 `شَنًّا`. Their printed source pages are in `word_review`.
- Repaired incomplete terminal vowels in H476 `زِرِّ`, H485 `أُمِّ`, H492 `أَعْرَابِيٌّ`, H521 `وَالتِّرْمِذِيُّ`, and H540 `وَالنَّسَائِيُّ`. Also removed malformed tanwīn from `إِلَّا` and `مُرْسَلًا` without changing their base letters.
- Rechecked earlier corrections in H474, H488, H492, H510, H526, and H556. Mirqāt p236 explicitly supports H556 `رَسُولُ` in the main reading and notes `رَسُولَ` as a manuscript variant; the B1 text keeps the main reading.

## Checks and proof status

- Removing vowel marks from each revised text exactly reproduces its corrected B1 lexical base. H471–563 coverage, order, and 93 row count pass. No impossible multiple short-vowel clusters, wholly unmarked words, or mechanically detectable short-vowel gaps remain. Quotes and parentheses are balanced.
- 3,059 of 3,275 words align exactly by base letters with Sunnah Arabic. The script added 638 compatible marks on 330 words. No marks were transferred from different-base words; none were transferred from the divergent H527 row.
- The final text differs from Bushrā **OCR** on 157 words. Forty-eight of these have a recorded visual source decision. The other 109 have an editorial reading, often agreeing with exact-base Sunnah or reflecting a standard inflection, but are **not printed-vowel proof**. Bushrā OCR can itself misread marks. The earlier 47 Mirqāt/Bushrā conflict count in the validation block is a historical transfer-stage metric, not a count of unresolved words.
- All 93 entries are editorially fully marked. They remain **pending complete page-by-page printed-vowel proof** and later scholarly verification. Zero `unresolved_word_count` means no mechanical vowel gaps; it does not assert that every editorial vowel has been proven from print.

No Usul.ai access or upload was performed.
