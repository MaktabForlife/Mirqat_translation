# Kitāb al-Ṭahārah B1 matn vocalisation: H281–370

This is a **revised editorial vowel draft** of the Mirqāt B1 lexical text. It is not a claim that every printed Mirqāt vowel has been reproduced or that Stage E verification is complete. The Mirqāt wording from `Consolidated_Review_04` is fixed; Bushrā and Sunnah.com are supplementary vowel witnesses. No Usul.ai material was used.

## Coverage and checks

- 90 of 90 assigned entries processed; 2,930 Arabic words.
- All 90 revised texts preserve the Mirqāt B1 base letters and punctuation after vowel marks are stripped.
- 2,825 words align exactly by base letters with Sunnah Arabic. The 105 unmatched words were not filled from Sunnah. Lower alignment occurs in H300, H304, H307, H311, and H316; the per-word record shows those gaps.
- Of 50 direct vowel conflicts, 44 retain the earlier Mirqāt/Bushrā-supported reading, 5 use an editorial Sunnah reading after review, and 1 remains unresolved. All 50 have a per-word conflict audit with both alternatives and source pages. This corrected an initial over-reliance on Sunnah for proper-name tanwīn and the name *al-Tarmidhī*.
- Two contextual mark completions and six final sukūns on *Mājah* were added. No duplicated tanwīn, incompatible vowel clusters, or previously identified forms such as `أَلَاَ`, `هَذَّا`, or `أَحَدٌّ` remain.
- Every multi-letter word has vowel marks. The only remaining unmarked non-long consonant is the deliberately unresolved case ending on `الْقِبْلَة` in H335. Solar article lāms and long-vowel letters are appropriately unmarked.

## Explicit unresolved readings

There are two word records in two entries. An enlarged Bushrā p77 scan supports ṭāʾ ḍamma in H295 `الطُّهُورَ`. Bushrā pp77 and 83 also resolved the earlier flags on H298, H299, and H353 at editorial level; H353 retains a note on the alternative mood endings discussed by Mirqāt.

| Hadith | Word(s) | Remaining issue |
| --- | --- | --- |
| 335 | `الْقِبْلَة` | Mirqāt omits the external witness's `مستدبر`; the case ending is withheld. |
| 356 | `يخرج` | Mirqāt commentary allows connected jussive and indicative readings. |

The JSON output includes the complete revised text, the immutable lexical text, exact word indexes, source words and decisions for all 90 entries. Its status remains **editorial vowel candidate** pending further reading against the printed witnesses.

## Second visual proof pass

Bushrā scan pages 75–85 were viewed across all 90 entries. I also inspected 35 Mirqāt page images and compared the 29 shorter entries listed below word by word against their complete Mirqāt page spans and corresponding Bushrā lines. These **29 entries are now editorially second-pass checked**. This means the supplied vowel choices have a second source-based reading; Mirqāt prints sparse vowel marks, so it does not mean that every vowel is a diplomatic transcription of Mirqāt or that Stage E is complete.

The checked entries are H283, 291, 293, 294, 300, 301, 304, 310–313, 315, 322, 325, 326, 328, 331, 332, 337, 341, 342, 344, 346, 354, 355, 359, 361, 362, and 364. The other **59 non-flagged entries** remain editorial candidates awaiting a complete word-by-word Mirqāt/Bushrā comparison; H335 and H356 retain their explicit unresolved readings.

The pass found one definite repeated mark error in H299: both occurrences of `يُؤْذَّنُ` are corrected to `يُؤْذَنُ`. Bushrā p77 and Mirqāt p24 support the ungeminated passive. The B1 base letters and punctuation are unchanged in all 90 entries. Mirqāt p49 discusses a reading with `مستدبر` before H335 `القبلة`, but this word is absent in the B1 matn; the case vowel remains withheld rather than silently restoring that word. H356's alternative verb endings remain as recorded above.
