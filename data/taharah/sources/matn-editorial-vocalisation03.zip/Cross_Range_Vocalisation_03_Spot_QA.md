# Tahārah B1 vocalisation 03: independent spot QA

Read-only review of ten selected entries in the **current** H371–470 and H471–563 drafts. I compared the indicated Mirqāt and Bushrā scan pages, then re-read the current output tokens. This is a spot check, not certification of either full range. No source or other agent output was changed.

| Hadith | Scans consulted | Current draft finding |
|---|---|---|
| 394 | Mirqāt pp. 97–99; Bushrā p. 88 | `بِإِنَّاءِ` has an impossible shadda on nūn and incorrect ending; read `بِإِنَاءٍ`. The final `غُرْفَةٍ` and `وَاسْتَنْشَقَ` / `وَاسْتَنْثَرَ` are now corrected in the current draft. |
| 407 | Mirqāt pp. 108–109; Bushrā p. 89 | `أَصَابَعَ` → `أَصَابِعَ` in `يُدَلِّكُ أَصَابِعَ رِجْلَيْهِ`. |
| 418 | Mirqāt pp. 116–117; Bushrā p. 90 | No remaining actionable vowel error in the current text sample; earlier `قَوْمٌّ` has been corrected to `قَوْمٌ`. |
| 440 | Mirqāt pp. 132–133; Bushrā p. 93 | No remaining actionable vowel error in the current text sample; earlier `كَنْتُ` and `وَبَينّه` were corrected. |
| 457 | Mirqāt pp. 145–146; Bushrā p. 95 | `إِنَّي` → `إِنِّي` in `إِنِّي كُنْتُ جُنُبًا`. |
| 527 | Mirqāt pp. 210–211; Bushrā p. 103 | No actionable vowel error found in the spot sample. |
| 531 | Mirqāt pp. 215–216; Bushrā pp. 103–104 | `أَلَّاَّ` → `أَلَّا` (duplicated fatḥa). Earlier errors `منَّا`, `الْعيّ`, and `جسدهِ` have been corrected in the current draft. |
| 533 | Mirqāt p. 217; Bushrā p. 104 | `أَتَّيَا` → `أَتَيَا`; the shadda on tāʾ is spurious. |
| 548 | Mirqāt p. 230; Bushrā p. 106 | No actionable vowel error found in the spot sample. |
| 559 | Mirqāt pp. 239–240; Bushrā p. 107 | `أُمّ سَلَمَةَ` → `أُمُّ سَلَمَةَ` as subject of `فَاسْتَفْتَتْ`; `لْتُصَلّ` needs final kasra, `لْتُصَلِّ`. Mirqāt's note permits either sukūn or kasra on the initial command lām after `ثُمَّ`, so retain that as an editorial variant. |

## B1 wording and status

No **additional** base-letter or wording defect emerged from these ten entries. That finding does not resolve the separately reported H518/H528 lexical errata, which were outside this ten-entry sample. The H371–470 range still labels these five entries `partial_editorial_vocalisation_unproofed`, despite reporting zero unresolved word indexes; the status should be reconciled after the token corrections. H471–563 marks its five as editorially vowel complete pending Mirqāt print proof, but H531, H533, and H559 still contain the specific defects above.
